package com.zybooks.kainanwoodardinventoryproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class InventoryDatabase extends SQLiteOpenHelper {
    public static final String DBNAME = "inventory.db";
    public static final int VERSION = 1;
    public InventoryDatabase(Context context) {
        super(context, DBNAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table items(itemName TEXT primary key, quantity TEXT, price TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop Table if exists items");
    }
    public Boolean insertData(String item, String quantity, String price){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemName", item);
        contentValues.put("quantity", quantity);
        contentValues.put("price", price);
        long result = db.insert("items",null,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }
    public Boolean updateData(String item, String quantity,String price) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("quantity", quantity);
        contentValues.put("price", price);
        Cursor cursor = db.rawQuery("Select * from items where itemName = ?", new String[]{item});
        if (cursor.getCount() > 0) {
            long result = db.update("items", contentValues, "itemName=?", new String[]{item});
            if (result == -1)
                return false;
            else
                return true;
        }else{
            return false;
        }
    }
    public Boolean deleteData(String item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Cursor cursor = db.rawQuery("Select * from items where itemName =?", new String[]{item});
        if (cursor.getCount() > 0) {
            long result = db.delete("items","itemName=?", new String[]{item});
            if (result == -1)
                return false;
            else
                return true;
        }else{
            return false;
        }
    }
    public Cursor viewData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from items", null);
        return cursor;
    }
}
