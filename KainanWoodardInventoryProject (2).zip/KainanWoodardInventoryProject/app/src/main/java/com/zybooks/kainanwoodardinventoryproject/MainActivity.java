package com.zybooks.kainanwoodardinventoryproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText userName, passWord;
    private Button logInButton, signUpButton;
    LoginDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_in_page);

        userName = findViewById(R.id.logInPageUserName);
        passWord = findViewById(R.id.logInPagePassword);
        logInButton = findViewById(R.id.logInPageLogInButton);
        signUpButton = findViewById(R.id.logInPageSignUpButton);
        db = new LoginDatabase(this);


        userName.addTextChangedListener(loginTextWatcher);
        passWord.addTextChangedListener(loginTextWatcher);

        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = userName.getText().toString();
                String pass = passWord.getText().toString();

                Boolean checkUserPass = db.checkUsernamePassword(user,pass);
                if(checkUserPass == true){
                        Toast.makeText(MainActivity.this,"Sign in successful", Toast.LENGTH_SHORT).show();
                        openInventoryPage();
                }else{
                        Toast.makeText(MainActivity.this,"invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSignUpPage();
            }
        });
    }
    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String userText = userName.getText().toString().trim();
            String passText = passWord.getText().toString().trim();
            logInButton.setEnabled(!userText.isEmpty() && !passText.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

    public void openSignUpPage(){
        Intent intent = new Intent(this, signUpPage.class);
        startActivity(intent);
    }
    public void openInventoryPage(){
        Intent intent = new Intent(this, inventoryPage.class);
        startActivity(intent);
    }
}