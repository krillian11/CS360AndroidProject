package com.zybooks.kainanwoodardinventoryproject;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;
import android.widget.TextView;

public class inventoryPage extends AppCompatActivity {
   private Button newItemBtn,profileBtn;
   private TextView viewItems;
   InventoryDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //recreate();
        //startActivity(getIntent());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_page);
        viewItems = findViewById(R.id.inventoryItems);
        newItemBtn = findViewById(R.id.inventoryNewItemButton);
        profileBtn = findViewById(R.id.inventoryProfileButton);
        db = new InventoryDatabase(this);

        Cursor inventoryItems = db.viewData();
        if(inventoryItems.getCount() == 0){
            viewItems.setText("No entries exist");
        }else {
            //String upperString = myString.substring(0, 1).toUpperCase() + myString.substring(1).toLowerCase();
            StringBuffer buffer = new StringBuffer();
            while (inventoryItems.moveToNext()) {
                buffer.append("Name: " + inventoryItems.getString(0).substring(0,1).toUpperCase() + inventoryItems.getString(0).substring(1).toLowerCase() + "\n");
                buffer.append("Quantity: " + inventoryItems.getString(1).substring(0,1).toUpperCase() + inventoryItems.getString(1).substring(1).toLowerCase() + "\n");
                buffer.append("Price: $" + inventoryItems.getString(2).substring(0,1).toUpperCase() + inventoryItems.getString(2).substring(1).toLowerCase() + "\n\n");
            }
            viewItems.setText(buffer.toString());
        }
        newItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewItemPage();
            }
        });
        profileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openProfilePage();
            }
        });
    }
    public void openProfilePage(){
        Intent intent = new Intent(this, profilePage.class);
        startActivity(intent);
    }
    public void openNewItemPage(){
        Intent intent = new Intent(this, newItemPage.class);
        startActivity(intent);
    }
}