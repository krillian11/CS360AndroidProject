package com.zybooks.kainanwoodardinventoryproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class profilePage extends AppCompatActivity {
    Button saveBtn;
    CheckBox notify;
    LoginDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_page);

        db = new LoginDatabase(this);
        saveBtn = findViewById(R.id.profilePageSaveButton);
        notify = findViewById(R.id.profilePageTextNotifs);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("Notification","Test", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel((channel));
        }

        saveBtn.setOnClickListener(new View.OnClickListener() { //not sure how to save notfications to account
            @Override
            public void onClick(View view) {
                if(notify.isChecked()){
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(profilePage.this,"Notification");
                    builder.setContentTitle("Test Notification");
                    builder.setContentText("This is a test notification");
                    builder.setSmallIcon(R.drawable.ic_launcher_background);
                    builder.setAutoCancel(true);

                    NotificationManagerCompat managerCompat = NotificationManagerCompat.from(profilePage.this);
                    managerCompat.notify(1,builder.build());
                }
            }
        });
    }
}