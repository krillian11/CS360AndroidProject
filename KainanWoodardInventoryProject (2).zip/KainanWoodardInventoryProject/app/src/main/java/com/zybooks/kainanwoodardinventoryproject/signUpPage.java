package com.zybooks.kainanwoodardinventoryproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class signUpPage extends AppCompatActivity {
    Button signUp;
    EditText userName, password, passwordConf;
    LoginDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_page);
        db = new LoginDatabase(this);
        signUp = findViewById(R.id.signUpPageButton);
        userName = findViewById(R.id.signUpUsername);
        password = findViewById(R.id.signUpPassword);
        passwordConf = findViewById(R.id.signUpPasswordConf);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = userName.getText().toString();
                String pass = password.getText().toString();
                String pass2 = passwordConf.getText().toString();

                if(user.equals("") || pass.equals("") || pass2.equals("")){
                    Toast.makeText(signUpPage.this,"Please enter all fields", Toast.LENGTH_SHORT).show();
                }else{
                    if(pass.equals(pass2)){
                        Boolean checkUser = db.checkUsername(user);
                        if (checkUser == false){
                            Boolean insert = db.insertData(user,pass);
                            if(insert == true){
                                Toast.makeText(signUpPage.this,"Registered successfully", Toast.LENGTH_SHORT).show();
                                openInventoryPage();
                            }else{
                                Toast.makeText(signUpPage.this,"Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            Toast.makeText(signUpPage.this,"User exists. Sign in.", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(signUpPage.this,"Passwords don't match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
    public void openInventoryPage(){
        Intent intent = new Intent(getApplicationContext(), inventoryPage.class);
        startActivity(intent);
    }
}