package com.zybooks.kainanwoodardinventoryproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class newItemPage extends AppCompatActivity {
    InventoryDatabase db;
    EditText itemName, itemPrice, itemQuantity;
    Button newItem,updateItem,deleteItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_item_page);

        itemName = findViewById(R.id.editTextItemName);
        itemPrice = findViewById(R.id.editTextPrice);
        itemQuantity = findViewById(R.id.editTextItemQty);

        newItem = findViewById(R.id.saveNewItem);
        updateItem = findViewById(R.id.updateNewItem);
        deleteItem = findViewById(R.id.deleteNewItem);
        db = new InventoryDatabase(this);

        itemName.addTextChangedListener(newItemTextWatcher);
        itemPrice.addTextChangedListener(newItemTextWatcher);
        itemQuantity.addTextChangedListener(newItemTextWatcher);

        newItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = itemName.getText().toString();
                String price = itemPrice.getText().toString();
                String quantity = itemQuantity.getText().toString();

                Boolean checkInsert = db.insertData(name,quantity,price);
                if(checkInsert == true) {
                    Toast.makeText(newItemPage.this, "Insertion Successful", Toast.LENGTH_SHORT).show();
                    openInventoryPage();
                }else
                    Toast.makeText(newItemPage.this, "Insertion Failed", Toast.LENGTH_SHORT).show();
            }
        });
        updateItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = itemName.getText().toString();
                String price = itemPrice.getText().toString();
                String quantity = itemQuantity.getText().toString();

                Boolean checkUpdate = db.updateData(name,quantity,price);
                if(checkUpdate == true) {
                    if(quantity.equals("0")){
                        StringBuffer buffer = new StringBuffer();
                        buffer.append("We are out of ");
                        buffer.append(name.substring(0,1).toUpperCase() + name.substring(1).toLowerCase() + " please restock!");
                        AlertDialog.Builder builder = new AlertDialog.Builder(newItemPage.this);
                        builder.setCancelable(true);
                        builder.setTitle("WARNING");
                        builder.setMessage(buffer.toString());
                        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                openInventoryPage();
                            }
                        });
                        builder.show();
                    }else {
                        Toast.makeText(newItemPage.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                        openInventoryPage();
                    }
                }else
                    Toast.makeText(newItemPage.this, "Update Failed", Toast.LENGTH_SHORT).show();
            }
        });
        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = itemName.getText().toString();


                Boolean checkDelete = db.deleteData(name);
                if(checkDelete == true) {
                    Toast.makeText(newItemPage.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                     openInventoryPage();
                }else
                    Toast.makeText(newItemPage.this, "Deletion Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private TextWatcher newItemTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String name = itemName.getText().toString();
            String price = itemPrice.getText().toString();
            String qty = itemQuantity.getText().toString();

            newItem.setEnabled(!name.isEmpty() && !price.isEmpty() && !qty.isEmpty());
            updateItem.setEnabled(!name.isEmpty() && !price.isEmpty() && !qty.isEmpty());
            deleteItem.setEnabled(!name.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
    public void openInventoryPage() {
        Intent intent = new Intent(this, inventoryPage.class);
        startActivity(intent);
    }
}